## Deck.gd
## Manages a collection of cards with shuffle, draw, and discard logic.

class_name Deck
extends RefCounted

var cards: Array[Card] = []
var discard_pile: Array[Card] = []

## Build a standard 52-card deck with no abilities.
static func build_standard() -> Deck:
	var deck = Deck.new()
	for suit in Card.Suit.values():
		for val in range(2, 15):  # 2–14 (Ace = 14)
			var c = Card.new()
			c.value = val
			c.suit = suit
			c.ability = Card.Ability.NONE
			deck.cards.append(c)
	deck.shuffle()
	return deck

## Build a half-deck (26 cards) for the player start.
static func build_player_start() -> Deck:
	var full = build_standard()
	var half = Deck.new()
	half.cards = full.cards.slice(0, 26)
	return half

## Build the enemy deck (other half).
static func build_enemy_start(player_deck: Deck) -> Deck:
	var full = build_standard()
	# Give enemy the complementary cards
	var enemy = Deck.new()
	enemy.cards = full.cards.slice(26, 52)
	return enemy

## Build a boss deck — 30 cards, weighted toward high values, some with abilities.
static func build_boss_deck(boss_level: int) -> Deck:
	var deck = Deck.new()
	# Bias toward high-value cards
	for _i in range(30):
		var c = Card.new()
		c.value = randi_range(7, 14)
		c.suit = Card.Suit.values()[randi() % 4]
		# Boss cards can have abilities
		if randf() < 0.3 + boss_level * 0.05:
			var abilities = [
				Card.Ability.SHIELD, Card.Ability.DOUBLE,
				Card.Ability.POISON, Card.Ability.DRAIN
			]
			c.ability = abilities[randi() % abilities.size()]
		c.is_boss_card = true
		deck.cards.append(c)
	deck.shuffle()
	return deck

func shuffle() -> void:
	cards.shuffle()

func draw() -> Card:
	if cards.is_empty():
		if not discard_pile.is_empty():
			recycle_discard()
		else:
			return null
	return cards.pop_front()

func add_to_bottom(card: Card) -> void:
	cards.append(card)

func add_to_top(card: Card) -> void:
	cards.push_front(card)

func discard(card: Card) -> void:
	discard_pile.append(card)

func recycle_discard() -> void:
	cards.append_array(discard_pile)
	discard_pile.clear()
	shuffle()

func count() -> int:
	return cards.size()

func total_count() -> int:
	return cards.size() + discard_pile.size()

func is_empty() -> bool:
	return cards.is_empty() and discard_pile.is_empty()

## Inject ability cards into the deck (used after upgrades).
func inject_ability_cards(ability: Card.Ability, count: int) -> void:
	for _i in range(count):
		var c = Card.new()
		c.value = randi_range(5, 13)
		c.suit = Card.Suit.values()[randi() % 4]
		c.ability = ability
		cards.append(c)
	shuffle()

## Remove lowest N cards (used by some upgrades).
func cull_weak_cards(n: int) -> void:
	cards.sort_custom(func(a, b): return a.value < b.value)
	for _i in range(min(n, cards.size())):
		cards.pop_front()
	shuffle()
