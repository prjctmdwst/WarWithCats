## GameState.gd
## Autoload singleton. Holds all persistent run data across scenes.

extends Node

# ── Run state ──────────────────────────────────────────────────────────────
var run_active: bool = false
var floor_number: int = 0       # Current floor (1-indexed)
var max_floors: int = 10        # Floors before final boss
var gold: int = 0               # Currency for the shop

# ── Decks (serialized between battles) ─────────────────────────────────────
var player_deck: Deck = null
var enemy_deck: Deck = null     # Set fresh each battle

# ── Player stats ───────────────────────────────────────────────────────────
var player_hp: int = 3          # Lose HP when deck is empty and opponent wins
var max_hp: int = 3
var shield_active: bool = false # Set by Shield ability

# ── Upgrades (persistent for the run) ──────────────────────────────────────
# Each entry: { "id": String, "name": String, "description": String, "level": int }
var upgrades: Array[Dictionary] = []

const ALL_UPGRADES = [
	{
		"id": "ace_high",
		"name": "Ace High",
		"description": "Aces are worth 15 instead of 14.",
		"max_level": 1,
	},
	{
		"id": "war_veteran",
		"name": "War Veteran",
		"description": "Win WAR ties without playing extra cards.",
		"max_level": 1,
	},
	{
		"id": "lucky_draw",
		"name": "Lucky Draw",
		"description": "After each battle, draw 3 random ability cards into your deck.",
		"max_level": 3,
	},
	{
		"id": "cull",
		"name": "Card Cull",
		"description": "Remove your 3 lowest cards at battle start.",
		"max_level": 2,
	},
	{
		"id": "resilience",
		"name": "Resilience",
		"description": "+1 max HP and restore 1 HP.",
		"max_level": 2,
	},
	{
		"id": "double_trouble",
		"name": "Double Trouble",
		"description": "Add 3 'Double Down' ability cards to your deck.",
		"max_level": 3,
	},
	{
		"id": "poison_ivy",
		"name": "Poison Ivy",
		"description": "Add 3 'Poison' ability cards to your deck.",
		"max_level": 3,
	},
	{
		"id": "mirror_shield",
		"name": "Mirror Shield",
		"description": "Add 2 'Mirror' + 2 'Shield' ability cards to your deck.",
		"max_level": 2,
	},
]

# ── Signals ─────────────────────────────────────────────────────────────────
signal run_started
signal floor_changed(floor: int)
signal player_hp_changed(hp: int, max_hp: int)
signal upgrade_acquired(upgrade: Dictionary)
signal run_ended(victory: bool)

# ── Run management ──────────────────────────────────────────────────────────
func start_new_run() -> void:
	run_active = true
	floor_number = 0
	gold = 0
	player_hp = 3
	max_hp = 3
	shield_active = false
	upgrades.clear()
	player_deck = Deck.build_player_start()
	run_started.emit()

func advance_floor() -> void:
	floor_number += 1
	floor_changed.emit(floor_number)

func is_boss_floor() -> bool:
	return floor_number % 5 == 0

func is_final_floor() -> bool:
	return floor_number >= max_floors

func get_boss_level() -> int:
	return floor_number / 5

# ── HP management ───────────────────────────────────────────────────────────
func take_damage(amount: int = 1) -> void:
	if shield_active:
		shield_active = false
		return
	player_hp = max(0, player_hp - amount)
	player_hp_changed.emit(player_hp, max_hp)
	if player_hp <= 0:
		end_run(false)

func heal(amount: int = 1) -> void:
	player_hp = min(max_hp, player_hp + amount)
	player_hp_changed.emit(player_hp, max_hp)

func is_dead() -> bool:
	return player_hp <= 0

# ── Upgrades ─────────────────────────────────────────────────────────────────
func has_upgrade(id: String) -> bool:
	for u in upgrades:
		if u["id"] == id:
			return true
	return false

func get_upgrade_level(id: String) -> int:
	for u in upgrades:
		if u["id"] == id:
			return u.get("level", 1)
	return 0

func acquire_upgrade(upgrade_data: Dictionary) -> void:
	# Check if already owned — if so, level it up
	for u in upgrades:
		if u["id"] == upgrade_data["id"]:
			u["level"] = u.get("level", 1) + 1
			_apply_upgrade_effect(upgrade_data["id"])
			upgrade_acquired.emit(u)
			return
	var entry = upgrade_data.duplicate()
	entry["level"] = 1
	upgrades.append(entry)
	_apply_upgrade_effect(upgrade_data["id"])
	upgrade_acquired.emit(entry)

func _apply_upgrade_effect(id: String) -> void:
	match id:
		"resilience":
			max_hp += 1
			heal(1)
		"lucky_draw":
			var abilities = [Card.Ability.SHIELD, Card.Ability.DOUBLE,
				Card.Ability.POISON, Card.Ability.RESURRECT]
			player_deck.inject_ability_cards(abilities[randi() % abilities.size()], 3)
		"cull":
			player_deck.cull_weak_cards(3)
		"double_trouble":
			player_deck.inject_ability_cards(Card.Ability.DOUBLE, 3)
		"poison_ivy":
			player_deck.inject_ability_cards(Card.Ability.POISON, 3)
		"mirror_shield":
			player_deck.inject_ability_cards(Card.Ability.MIRROR, 2)
			player_deck.inject_ability_cards(Card.Ability.SHIELD, 2)

## Return 3 random upgrades the player can choose from (not maxed out).
func get_upgrade_choices(count: int = 3) -> Array[Dictionary]:
	var available: Array[Dictionary] = []
	for u in ALL_UPGRADES:
		var current_level = get_upgrade_level(u["id"])
		if current_level < u.get("max_level", 1):
			available.append(u)
	available.shuffle()
	return available.slice(0, min(count, available.size()))

# ── Run end ──────────────────────────────────────────────────────────────────
func end_run(victory: bool) -> void:
	run_active = false
	run_ended.emit(victory)
