## MainMenu.gd
extends Control

@onready var start_button: Button = $VBox/StartButton
@onready var quit_button: Button = $VBox/QuitButton
@onready var title_label: Label = $VBox/Title
@onready var subtitle_label: Label = $VBox/Subtitle

func _ready() -> void:
	start_button.pressed.connect(_on_start)
	quit_button.pressed.connect(func(): get_tree().quit())

	# Animate title
	var tween = create_tween().set_loops()
	tween.tween_property(title_label, "modulate:a", 0.7, 1.2)
	tween.tween_property(title_label, "modulate:a", 1.0, 1.2)

func _on_start() -> void:
	GameState.start_new_run()
	GameState.advance_floor()
	get_tree().change_scene_to_file("res://scenes/Battle.tscn")
