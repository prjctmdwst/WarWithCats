## CardVisual.gd
## Controls the visual representation of a single card.
## Attach to a Control node that has child Label nodes.

class_name CardVisual
extends PanelContainer

@onready var value_label: Label = $VBox/ValueLabel
@onready var suit_label: Label = $VBox/SuitLabel
@onready var ability_label: Label = $VBox/AbilityLabel
@onready var ability_desc: Label = $VBox/AbilityDesc

var card_data: Card = null
var is_face_down: bool = false

# Tween reference for animations
var _tween: Tween

func display(card: Card, face_down: bool = false) -> void:
	card_data = card
	is_face_down = face_down
	_refresh()

func flip_face_up() -> void:
	if not is_face_down:
		return
	is_face_down = false
	# Flip animation: scale X to 0, change content, scale back
	_tween = create_tween()
	_tween.tween_property(self, "scale:x", 0.0, 0.1)
	_tween.tween_callback(_refresh)
	_tween.tween_property(self, "scale:x", 1.0, 0.1)

func play_win_animation() -> void:
	_tween = create_tween()
	_tween.tween_property(self, "position:y", position.y - 20, 0.15)
	_tween.tween_property(self, "position:y", position.y, 0.15)

func play_lose_animation() -> void:
	_tween = create_tween()
	_tween.tween_property(self, "modulate:a", 0.3, 0.3)
	_tween.tween_property(self, "modulate:a", 1.0, 0.2)

func play_ability_animation() -> void:
	_tween = create_tween()
	_tween.tween_property(self, "scale", Vector2(1.15, 1.15), 0.12)
	_tween.tween_property(self, "scale", Vector2(1.0, 1.0), 0.12)

func _refresh() -> void:
	if is_face_down:
		value_label.text = "?"
		suit_label.text = "🂠"
		ability_label.text = ""
		ability_desc.text = ""
		add_theme_stylebox_override("panel", _make_back_style())
	else:
		if card_data == null:
			return
		value_label.text = card_data.get_display_value()
		suit_label.text = card_data.get_suit_symbol()
		ability_label.text = card_data.get_ability_name()
		ability_desc.text = card_data.get_ability_description()

		# Color by suit
		var color = Color.RED if card_data.is_red() else Color.BLACK
		value_label.add_theme_color_override("font_color", color)
		suit_label.add_theme_color_override("font_color", color)

		# Boss card styling
		if card_data.is_boss_card:
			add_theme_stylebox_override("panel", _make_boss_style())
		elif card_data.ability != Card.Ability.NONE:
			add_theme_stylebox_override("panel", _make_ability_style())
		else:
			add_theme_stylebox_override("panel", _make_normal_style())

func _make_normal_style() -> StyleBoxFlat:
	var s = StyleBoxFlat.new()
	s.bg_color = Color(0.98, 0.96, 0.90)
	s.border_width_left = 2
	s.border_width_right = 2
	s.border_width_top = 2
	s.border_width_bottom = 2
	s.border_color = Color(0.3, 0.3, 0.3)
	s.corner_radius_top_left = 8
	s.corner_radius_top_right = 8
	s.corner_radius_bottom_left = 8
	s.corner_radius_bottom_right = 8
	return s

func _make_ability_style() -> StyleBoxFlat:
	var s = _make_normal_style()
	s.bg_color = Color(0.90, 0.94, 1.0)
	s.border_color = Color(0.2, 0.4, 0.9)
	s.border_width_left = 3
	s.border_width_right = 3
	s.border_width_top = 3
	s.border_width_bottom = 3
	return s

func _make_boss_style() -> StyleBoxFlat:
	var s = _make_normal_style()
	s.bg_color = Color(0.25, 0.05, 0.05)
	s.border_color = Color(0.9, 0.6, 0.1)
	s.border_width_left = 3
	s.border_width_right = 3
	s.border_width_top = 3
	s.border_width_bottom = 3
	return s

func _make_back_style() -> StyleBoxFlat:
	var s = StyleBoxFlat.new()
	s.bg_color = Color(0.1, 0.2, 0.6)
	s.border_width_left = 2; s.border_width_right = 2
	s.border_width_top = 2; s.border_width_bottom = 2
	s.border_color = Color(0.7, 0.8, 1.0)
	s.corner_radius_top_left = 8; s.corner_radius_top_right = 8
	s.corner_radius_bottom_left = 8; s.corner_radius_bottom_right = 8
	return s
