## Card.gd
## Represents a single playing card with optional special ability.

class_name Card
extends Resource

enum Suit { CLUBS, DIAMONDS, HEARTS, SPADES }
enum Ability {
	NONE,
	SHIELD,       # Block the next loss (once per battle)
	DOUBLE,       # If you win, gain 2x the cards
	POISON,       # Opponent discards top card of their winnings
	RESURRECT,    # If you lose, flip again with a 50% bonus
	DRAIN,        # Steal 1 card from opponent's deck on win
	MIRROR,       # Copy opponent's card value this round
	BOMB,         # Both players discard played cards (no gain, no loss)
	GOLD,         # Worth 2 points in scoring
}

const ABILITY_NAMES = {
	Ability.NONE:      "",
	Ability.SHIELD:    "Shield",
	Ability.DOUBLE:    "Double Down",
	Ability.POISON:    "Poison",
	Ability.RESURRECT: "Resurrect",
	Ability.DRAIN:     "Drain",
	Ability.MIRROR:    "Mirror",
	Ability.BOMB:      "Bomb",
	Ability.GOLD:      "Gold",
}

const ABILITY_DESCRIPTIONS = {
	Ability.NONE:      "",
	Ability.SHIELD:    "Block the next loss this battle.",
	Ability.DOUBLE:    "Win? Collect 2x cards.",
	Ability.POISON:    "Opponent discards a won card.",
	Ability.RESURRECT: "Lose? Flip again with +3 bonus.",
	Ability.DRAIN:     "On win, steal 1 card from opponent.",
	Ability.MIRROR:    "Copies opponent's card value.",
	Ability.BOMB:      "Both played cards are discarded.",
	Ability.GOLD:      "Worth double in final scoring.",
}

const SUIT_SYMBOLS = {
	Suit.CLUBS:    "♣",
	Suit.DIAMONDS: "♦",
	Suit.HEARTS:   "♥",
	Suit.SPADES:   "♠",
}

const VALUE_NAMES = {
	1: "A", 2: "2", 3: "3", 4: "4", 5: "5",
	6: "6", 7: "7", 8: "8", 9: "9", 10: "10",
	11: "J", 12: "Q", 13: "K", 14: "A"
}

@export var value: int = 2       # 2–14 (Ace high = 14)
@export var suit: Suit = Suit.CLUBS
@export var ability: Ability = Ability.NONE
@export var is_boss_card: bool = false

func get_display_value() -> String:
	return VALUE_NAMES.get(value, str(value))

func get_suit_symbol() -> String:
	return SUIT_SYMBOLS.get(suit, "?")

func get_ability_name() -> String:
	return ABILITY_NAMES.get(ability, "")

func get_ability_description() -> String:
	return ABILITY_DESCRIPTIONS.get(ability, "")

func is_red() -> bool:
	return suit == Suit.DIAMONDS or suit == Suit.HEARTS

func get_effective_value(opponent_value: int = 0) -> int:
	if ability == Ability.MIRROR:
		return opponent_value
	return value

func to_string() -> String:
	return "%s%s" % [get_display_value(), get_suit_symbol()]
